//typedef.cpp
//2013/12/08 written by shift

//typedef�錾
typedef unsigned int uint;
typedef unsigned char byte;
typedef unsigned long ulong;

