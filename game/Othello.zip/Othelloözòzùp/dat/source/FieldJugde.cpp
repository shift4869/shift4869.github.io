#include "../include/main.h"

//�Ֆʕ]���֐�
int FieldJudge(STONE_KND k,const vector<Stone>& field/*=fieldStone*/){
	const int EvalScore[SNUM][SNUM]={
		30	,-12,0	,-1	,-1	,0	,-12,30	,
		-12	,-15,-3	,-3	,-3	,-3	,-15,-12,
		0	,-3	,0	,-1	,-1	,0	,-3	,0	,
		-1	,-3	,-1	,-1	,-1	,-1	,-3	,-1	,
		-1	,-3	,-1	,-1	,-1	,-1	,-3	,-1	,
		0	,-3	,0	,-1	,-1	,0	,-3	,0	,
		-12	,-15,-3	,-3	,-3	,-3	,-15,-12,
		30	,-12,0	,-1	,-1	,0	,-12,30	,
	};
	int whiteScore=0,blackScore=0;

	for(vector<Stone>::const_iterator it=field.begin();
		it!=field.end();++it){
		switch(it->knd){
			case WHITE:
				whiteScore+=EvalScore[it->z.x][it->z.y];
				break;
			case BLACK:
				blackScore+=EvalScore[it->z.x][it->z.y];
				break;
			default:
				throw("FieldJudge switch error");
		}
	}

	return ((k==WHITE)?whiteScore:blackScore);
}