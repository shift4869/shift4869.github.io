#define _FIRST_LOADING_
#include "../include/main.h"
/*#include <new.h>
#define _CRTDBG_MAP_ALLOC
#include <crtdbg.h>
#define new new(_NORMAL_BLOCK,__FILE__,__LINE__)*/

bool ProcessLoop(){
	if(ProcessMessage()!=0)			return false;
	if(ClearDrawScreen()!=0)		return false;
	if(GetHitKeyStateAll_2(key)!=0)	return false;
	if(GetHitPadStateAll()!=0)		return false;
	if(GetHitMouseStateAll_2(mouse)!=0)return false;
	if(CheckStatePad(config.start)!=0)return false;
	return true;
}

int WINAPI WinMain( HINSTANCE hInstance, HINSTANCE hPrevInstance,LPSTR lpCmdLine, int nCmdShow ){
	//���������[�N���o�p
	//_CrtSetReportMode(_CRT_WARN, _CRTDBG_MODE_FILE);
	//_CrtSetReportFile(_CRT_WARN, _CRTDBG_FILE_STDERR);
	_CrtSetDbgFlag(_CRTDBG_ALLOC_MEM_DF | _CRTDBG_LEAK_CHECK_DF);
	//_CrtSetBreakAlloc(1092);

	ChangeWindowMode(TRUE);//�E�B���h�E���[�h
	
	if(DxLib_Init()==-1 || SetDrawScreen(DX_SCREEN_BACK)!=0)return -1;//�������Ɨ���ʉ�
	
	init();

	try{
		while(ProcessLoop() && !isGameEnd){
			gamePlayer->control();
			
			drawMain();

			if(isTurnEnd){
				STONE_KND preKnd=gamePlayer->knd;
				delete gamePlayer;
				/*if(gamePlayer==&player){
					gamePlayer=&npcplayer;
				}
				else{
					gamePlayer=&player;
				}*/
				switch(preKnd){
					case BLACK://�v���C���[->NPC
						gamePlayer=new NPCPlayer;
						break;
					case WHITE://NPC->�v���C���[
						gamePlayer=new Player;
						break;
					default:
						throw("turn end error");
				}
				isTurnEnd=false;
			}

			fps();

			ScreenFlip();
		}

	}
	catch(const String &e){
		MessageBox(NULL,e,"error",NULL);
		delete gamePlayer;
		DxLib_End();
	}
	catch(const char *e){
		MessageBox(NULL,e,"error",NULL);
		delete gamePlayer;
		DxLib_End();
	}
	catch(...){
		MessageBox(NULL,"Unknown Error!","error",NULL);
		delete gamePlayer;
		DxLib_End();
	}

	delete gamePlayer;
	DxLib_End();

	return 0;
}

