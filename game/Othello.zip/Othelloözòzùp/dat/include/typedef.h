
//typedef�錾
typedef unsigned int uint;
typedef unsigned char byte;
typedef unsigned long ulong;

