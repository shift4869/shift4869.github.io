//Fextern.h by_shift 2009/03/11
//�ecpp�t�@�C���ւ̊֐��v���g�^�C�v�錾

//�C�����C���֐���`
#include "inline.h"

//key.cpp
int CheckStatePad(unsigned int Handle);
int GetHitKeyStateAll_2(unsigned int GetHitKeyStateAll_InputKey[]);
int GetHitPadStateAll();

//run.cpp
void deltask(int LIST);

//funcs.cpp-------------------------------------------

//�ėp�֐��Q
Point playerpoint();
float toplayer(const Point* from);
float fdeg360(float deg);
float distance(const Point* p1,const Point* p2);
float distance2(const Point* p1,const Point* p2);

//�Z�b�g�֐���
void set_bar(Bar *bawork,const Point *start,int len,float spd);
void set_bar_sp(Bar *bawork);

void set_ball(Ball *balwork,const Point *start,
			  float ang,float spd,float r,float pow,int time=120);

void set_block(Block *blwork,const Point *start,
			   float wide,float high,
			   int knd,int col,int hp,int itemknd);
void set_block_sp(Block *blwork);

void set_item(Item *iwork,const Point *start,
			  int knd, float ang, float spd);

//----------------------------------------------------

//bar.cpp
//Bar�v���Z�X�֐�
void bar_process(Task *task);
void bar_draw(Task *task);

//ball.cpp
//Ball�v���Z�X�֐�
void ball_wait(Task *task);
void ball_process(Task *task);
void ball_draw(Task *task);

//block.cpp
//Block�v���Z�X�֐�
void block_process(Task *task);
void block_draw(Task *task);

//item.cpp
//Item�v���Z�X�֐�
void item_draw(Task *task);
void item_move(Task *task);
void item_ability(Task *task);
void item_time(Task *task);
void item_end(Task *task);

//hit.cpp
//check.cpp�p�ڐG���̋����֐�
void hit_bar_ball(Task *bartask,Task *baltask);
void hit_bar_item(Task *itask);
void hit_block_ball(Task *blktask,Task *baltask,int i,int issen);
