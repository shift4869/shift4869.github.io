#include "../include/GVextern.h"


int GetHitKeyStateAll_2(unsigned int GetHitKeyStateAll_InputKey[]){
    char GetHitKeyStateAll_Key[256];
    GetHitKeyStateAll( GetHitKeyStateAll_Key );
    for(int i=0;i<256;i++){
        if(GetHitKeyStateAll_Key[i]==1) GetHitKeyStateAll_InputKey[i]++;
        else                            GetHitKeyStateAll_InputKey[i]=0;
    }
    return 0;
}

int CheckStateKey(unsigned char Handle){
    return Key[Handle];
}

void pad_or_key_max(int *p, int k){
    *p = *p>k ? *p : k;
}

//�p�b�h�ƃL�[�{�[�h�̗����̓��͂��`�F�b�N����֐�
int GetHitPadStateAll(){
    int i,PadInput,mul=1;
	int configkey[]={
		config.left, config.up , config.right, config.down ,
		config.shot, config.bom, config.slow , config.start, config.change,
	};
	unsigned int keyinput[]={
		KEY_INPUT_LEFT, KEY_INPUT_UP, KEY_INPUT_RIGHT , KEY_INPUT_DOWN  ,
		KEY_INPUT_Z   , KEY_INPUT_X , KEY_INPUT_LSHIFT, KEY_INPUT_ESCAPE, KEY_INPUT_LCONTROL,
	};
    PadInput = GetJoypadInputState( DX_INPUT_PAD1 );//�p�b�h�̓��͏�Ԃ��擾
    for(i=0;i<16;i++){
            if(PadInput & mul)  pad.key[i]++;
            else                pad.key[i]=0;
            mul*=2;
    }

	for(int i=0;i<9;i++){
		pad_or_key_max(&pad.key[configkey[i]],CheckStateKey(keyinput[i]));
	}

	return 0;
}

//�n���ꂽ�p�b�h�L�[�ԍ��̓��͏�Ԃ�Ԃ��B�Ԃ�l��-1�Ȃ�s��
int CheckStatePad(unsigned int Handle){
    if(0<=Handle && Handle<PAD_MAX){
        return pad.key[Handle];
    }
    else{
        printfDx("CheckStatePad�ɓn�����l���s���ł�\n");
        return -1;
    }
}
