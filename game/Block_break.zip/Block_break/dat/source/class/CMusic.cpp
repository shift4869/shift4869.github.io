#include "../../include/game_GVextern.h"

Music::Music(){
	flag=0;
	handle=0;
	knd=0;
	loop_pos[0]=loop_pos[1]=0;
}

#define BGM_FILE_NUM 1
void Music::load(){
	char bgmfile[BGM_FILE_NUM][64]={
		"./dat/resource/bgm/kyoumei.mp3",
	};

	handle=LoadSoundMem(bgmfile[knd]);
	ChangeVolumeSoundMem(50,handle);
	wait=60;
}

void Music::play(){
	int r=CheckSoundMem(handle);
	if(CheckSoundMem(handle)==1)return;//���t���Ȃ甲����
	if(wait>0){
		wait--;
		return;
	}

	PlaySoundMem(handle,DX_PLAYTYPE_LOOP);
}

void Music::stop(){
	if(CheckSoundMem(handle)==1){//���t���Ȃ�
		StopSoundMem(handle);
	}
}