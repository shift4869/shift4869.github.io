#include "../../include/game_GVextern.h"

int Block::num=0;
