#include "../../include/game_GVextern.h"

unsigned int Item::bitflag=0;