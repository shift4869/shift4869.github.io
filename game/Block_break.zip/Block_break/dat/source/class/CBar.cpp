#include "../../include/game_GVextern.h"

int Bar::num=2;