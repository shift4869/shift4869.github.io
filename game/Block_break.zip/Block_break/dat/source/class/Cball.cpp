#include "../../include/game_GVextern.h"

int Ball::num=0;