#include "../../../include/GVextern.h"
#include "../../../include/tilte_class.h"

void Title::se_set(){
	memset(seflag,0,sizeof(bool)*T_SE_MAX);
}

void Title::se_play(){
	for(int i=0;i<T_SE_MAX;i++){
		if(seflag[i])PlaySoundMem(sefile[i],DX_PLAYTYPE_BACK);
	}
}
