#include "../../../include/GVextern.h"
#include "../../../include/tilte_class.h"

void Title::draw_back(){
	DrawGraph(0,0,img_title,false);
}

void Title::draw_switch(){
	for(int i=0;i<T_STR_MAX;i++){
		if(str[i][0]==0)break;
		DrawStringToHandle(500,300+i*15,str[i],((i!=it)?gray:white),font[0]);
	}
}