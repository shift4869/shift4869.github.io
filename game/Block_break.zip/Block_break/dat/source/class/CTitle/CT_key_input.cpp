#include "../../../include/GVextern.h"
#include "../../../include/tilte_class.h"

void Title::key_input(){
	int up=CheckStatePad(config.up);
	int down=CheckStatePad(config.down);
	
	if(up==1 || (up>=30 && up%5==0)){
		it--;
		if(it<0){it=T_STR_MAX-1;}
		seflag[0]=true;
	}
	if(down==1 || (down>=30 && down%5==0)){
		it++;
		it%=T_STR_MAX;
		seflag[0]=true;
	}

}