#include "../../../include/GVextern.h"
#include "../../../include/tilte_class.h"

void Title::run(){
	int push=CheckStatePad(config.shot);
	if(push==1){
		seflag[1]=true;
		switch(it){
			case 0:
				block_break.f=&Block_break::game;
				break;
			case T_STR_MAX-1:
				block_break.isbb=false;
				break;
			default:
				printfDx("run::error!");
				break;
		}
		istitle=false;
	}
}