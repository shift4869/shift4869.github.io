#include "../include/game_GVextern.h"

//��̎��@���W��Ԃ�(Point)
Point playerpoint(){
	Point pt(-1,-1);
	TASKLOOP(p,BAR){
		Bar* pwork=(Bar*)p->work;
		pt.x=pwork->x;
		pt.y=pwork->y;
	}
	return pt;
}

//���@�_���̊p�x��Ԃ�(float deg)
float toplayer(const Point* from){
	TASKLOOP(b,BAR){
		Bar* bawork=(Bar*)b->work;
		//��(RTOD(atan2(y-pwork->y,x-pwork->x))+180);
		return (atan2d(from,(Point*)bawork));
	}
	return -1;
}

//�p�x(deg)��0~360�Ɏ��߂�
float fdeg360(float deg){
	float extra;
	for(;deg<=0.0;deg+=360.0);
	extra=deg-floor(deg);
	deg=(int)deg%360;
	return (deg+extra);
}

//2�_�Ԃ̋���
float distance(const Point* p1,const Point* p2){
	float dx,dy,dist;
	dx=(p2->x-p1->x);
	dy=(p2->y-p1->y);
	dist=sqrt(dx*dx+dy*dy);
	return dist;
}

//2�_�Ԃ̋�����2��
float distance2(const Point* p1,const Point* p2){
	float dx=(p2->x-p1->x);
	float dy=(p2->y-p1->y);
	return (dx*dx+dy*dy);
}


//�Z�b�g�o�[
void set_bar(Bar *bawork,const Point *start,int len,float spd){
	bawork->cnt=0;
	bawork->len=len;
	bawork->spd=spd;
	bawork->x=start->x;
	bawork->y=start->y;
	set_bar_sp(bawork);
}

void set_bar_sp(Bar *bawork){
	bawork->sp[0].x=bawork->x-bawork->len/2;bawork->sp[0].y=bawork->y;
	bawork->sp[1].x=bawork->x+bawork->len/2;bawork->sp[1].y=bawork->y;
}

//�Z�b�g�{�[��
void set_ball(Ball *balwork,const Point *start,
			  float ang,float spd,float r,float pow,int time/*=120*/){
	balwork->x=start->x;
	balwork->y=start->y;
	balwork->ang=ang;
	balwork->spd=spd;
	balwork->r=r;
	balwork->pow=pow;
	Ball::num++;
	balwork->time=time;//�ҋ@����
}

//�Z�b�g�u���b�N
void set_block(Block *blwork,const Point *start,
			   float wide,float high,
			   int knd,int col,int hp,int itemknd){
	blwork->x=start->x;
	blwork->y=start->y;
	blwork->wide=wide;
	blwork->high=high;
	blwork->knd=knd;
	blwork->col=col;
	blwork->hp=hp;
	blwork->itemknd=itemknd;
	set_block_sp(blwork);
	Block::num++;
}

void set_block_sp(Block *blwork){
	blwork->sp[0].x=blwork->x-blwork->wide/2;blwork->sp[0].y=blwork->y-blwork->high/2;
	blwork->sp[1].x=blwork->x+blwork->wide/2;blwork->sp[1].y=blwork->y-blwork->high/2;
	blwork->sp[2].x=blwork->x+blwork->wide/2;blwork->sp[2].y=blwork->y+blwork->high/2;
	blwork->sp[3].x=blwork->x-blwork->wide/2;blwork->sp[3].y=blwork->y+blwork->high/2;
}

extern void(*ability[ITEM_MAX_KND])(Item *iwork);
extern void(*endlity[ITEM_MAX_KND])(Item *iwork);
//�Z�b�g�A�C�e��
void set_item(Item *iwork,const Point *start,
/*			*/int knd, float ang, float spd){

	assert(0<=iwork->knd && iwork->knd<ITEM_MAX_KND);
	
	iwork->x=start->x;
	iwork->y=start->y;
	iwork->knd=knd;
	iwork->ang=ang;
	iwork->spd=spd;
	iwork->draw=true;
	iwork->flag=false;
	iwork->time=0;
	iwork->ability=ability[knd];
	iwork->endlity=endlity[knd];
}