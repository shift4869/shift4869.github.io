#include "../include/GVextern.h"

void fps(){
	static int frame;
	static int Ftime;
	static double fps;
	if(frame==0){
		Ftime=GetNowCount();
	}
	else if(frame==40){
		fps=1000.0f/((GetNowCount()-Ftime)/40.0f);
		frame=-1;
	}
	frame++;
	DrawFormatString(560,460,white,"fps=%2f",fps);
}