//hit.cpp by_shift 2009/03/16
//�ڐG���̋����̐ݒ�
//check.cpp����e�֐����Ăяo��

#include "../include/game_GVextern.h"

void hit_bar_ball(Task *bartask,Task *baltask){
	assert(bartask->kind==BAR && baltask->kind==BALL);
	
	//���ʎq���ӁI
	Bar* bawork=(Bar*)bartask->work;
	Ball* balwork=(Ball*)baltask->work;

	//balwork->ang=ref(balwork->ang,false);
	balwork->y=bawork->y-(balwork->r+2);
	balwork->ang=atan2d(bawork,balwork);
	if(340<balwork->ang && balwork->ang<360)balwork->ang=340;
	if(180<balwork->ang && balwork->ang<200)balwork->ang=200;

	score.add(100);

	se.se_flag[1]=true;
}

void hit_bar_item(Task *itask){
	assert(itask->kind==ITEM);
	
	Item *iwork=(Item*)itask->work;

	iwork->draw=false;//�`��t���O���I�t��

	se.se_flag[3]=true;

	itask->func[0]=item_ability;//���ʔ���
}

void hit_block_ball(Task *blktask,Task *baltask,int i,int issen){
	assert(blktask->kind==BLOCK && baltask->kind==BALL);
		
	Block *blwork=(Block*)blktask->work;
	Ball *balwork=(Ball*)baltask->work;


	if(!(Item::bitflag & I_METAL)){
		if(issen==1){
			if(i%2==0){
				balwork->y=blwork->sp[i].y+((i==0)?(-balwork->r-2):(balwork->r+2));
				balwork->ang=ref(balwork->ang,false);
			}
			else {
				balwork->x=blwork->sp[i].x+((i==1)?(balwork->r+2):(-balwork->r-2));
				balwork->ang=ref(balwork->ang,true);
			}
		}
		else{
			if(i%2==0)	{balwork->y=blwork->sp[i].y+((i==0)?(-balwork->r-2)/*0*/:(balwork->r+2)/*2*/);}
			else		{balwork->x=blwork->sp[i].x+((i==1)?(balwork->r+2)/*1*/:(-balwork->r-2)/*3*/);}
			balwork->ang=fdeg360(atan2d((Point*)blwork,&blwork->sp[i]));
		}
	}
	blwork->hp-=balwork->pow;
	blwork->col++;
	if(blwork->hp<=0){
		if(blwork->itemknd!=-1 || (GetRand(5)+1)==5 /*��20%*/){
			//�A�C�e���̐���----------------------------------------------------
			Task *itask=new Task(ITEM,item_move,item_draw);
			Item *iwork=(Item*)itask->work;
			Point st(blwork->x,blwork->y);
			int knd=(blwork->itemknd!=-1)?blwork->itemknd:GetRand(ITEM_MAX_KND-1);
			//Item *iwork,Point start,int knd,float ang,float spd
			set_item(iwork,&st,knd,90,3);
			//------------------------------------------------------------------
		}

		if(blwork->y!=FMY)Block::num--;
		delete blktask;			

	}

	se.se_flag[2]=true;

}

